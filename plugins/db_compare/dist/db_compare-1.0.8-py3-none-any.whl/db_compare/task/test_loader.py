from db_compare import Plugin


def test_loader():
    p = Plugin
    print(p.home)